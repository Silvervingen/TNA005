function [t,z] = RK4(f, tspan,n,y0)
%Runge Kutta method
%f, Function in
%tspan, tspan start & end point
%n, number of calculations
%y0, value of y(0)
a = tspan(1);
b = tspan(2);
t = linspace(a,b,n+1);
h = t(2)-t(1);
z = zeros(length(y0),length(t));
z(:,1) = y0;
for i = 1:n

s1 = h*f(t(i),z(:,i)); 
s2 = h*f(t(i)+h/2, z(:,i)+s1/2); 
s3 = h*f(t(i)+h/2, z(:,i)+s2/2); 
s4 = h*f(t(i)+h, z(:,i)+s3); 

z(:,i+1) = z(:,i) + (s1+ 2*s2 + 2 * s3 + s4)/6;
%t(i + 1) = z(:,1) + h * i;
end
