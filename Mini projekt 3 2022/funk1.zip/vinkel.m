function v = vinkel(t)

if (t <= 3.2)
   v = 2*pi/3;
   
elseif (t>3.2 && t<=7.5)
    v = (5* pi/ 4);
    
elseif (t>7.5 && t<=9)
    v = (pi);
    
elseif (t>9 && t<=10)
    v = (pi/2);

elseif (t>10 && t<=17)
    v = (3*pi/2);
    
elseif (t>17 && t<=21)
    v = (3 * pi / 4);

    
else
    v = pi;
end
end