function [m,dm] = mass_of_t(t)

if (0<=t && t <= 40)
   m = 40 - 0.5*t;
   dm = -0.5;
else
   m = 20;
   dm = 0;
end
        
end