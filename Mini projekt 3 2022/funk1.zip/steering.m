function [ux,uy] = steering(t)
km = 2000;
ux = km*cos(vinkel(t));
uy = km*sin(vinkel(t));
end