function z = funk2(t,z)
c = 0.25;
g = 9.82;

v1 = 60;

[m,dm] = mass_of_t(t);
[ux,uy] = steering(t);

z = [z(2); 
    -c/m*sqrt((z(2)^2)+(z(4)^2))*z(2) + ux*(dm/m);
    z(4);
    -c/m*sqrt((z(2)^2)+(z(4)^2))*z(4) + uy*(dm/m) - g;
];

end

