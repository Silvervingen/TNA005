function [x,y] = kast(k,m,v0,a,t)

g = 9.82;
x = -2 + t/2+ 3*exp(-t/2);
%x = ((m*v0*cos(a))/k - ((m*v0*cos(a))/k*exp(-(k/m)*t)));
y = -2 + t/2+ 3*exp(-t/2);-g*m/k*t;

end

