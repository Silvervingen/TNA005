function [t,y] = odeRK2(fun,tspan,y1,n)

h = (tspan(2)-tspan(1))/n;
t = linspace(tspan(1),tspan(2),n+1);
y(:,1) = y1;

for i = 1:n
    k1 = h * fun(t(i), y(:,i));
    k2 = h * fun(t(i)+ h, (y(:,i)+k1));
    y(:,i+1) = y(:,i) + (k1+k2)/2;
end
end


