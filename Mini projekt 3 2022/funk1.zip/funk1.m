function dz = funk1(t,z)
k = 4;
m = 8;
g = 9.82;
c1 = 3;
c2 = -2;

dz = [z(2) 
    -(k/m)*z(2) 
    z(4) 
    -g-(k/m)*z(4)];
end

